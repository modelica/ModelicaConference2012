This library is licensed under the terms of the Modelica License Version 2 (or newer)<br />
https://modelica.org/licenses